from django.apps import AppConfig


class ManagerappConfig(AppConfig):
    name = 'managerapp'
